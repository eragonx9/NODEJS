Following is node js code that can be used as a file manager via postman commands or server.
